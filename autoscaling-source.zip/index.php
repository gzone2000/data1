<center>
<br/>
<br/>
<?php
echo "<h3>CPU Load: ";
include 'getcpuload.php';
echo "</h3></br></br>";
include 'putcpuload.php';
session_start();
if (isset($_SESSION['genload'])) echo "<meta http-equiv=\"refresh\" content=\"5\" />";
?>
</center>
</div>